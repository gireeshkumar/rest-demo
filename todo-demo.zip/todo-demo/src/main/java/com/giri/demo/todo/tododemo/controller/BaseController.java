package com.giri.demo.todo.tododemo.controller;

public abstract class BaseController {

    public long getCurrentUserId(){
        //TODO fix this to load from the logged in user
        return 100;
    }
}
