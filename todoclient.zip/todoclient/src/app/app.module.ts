import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule} from "@angular/forms";
import {HttpModule} from "@angular/http";

import { AppComponent } from './app.component';
import { TodoComponentComponent } from './todo-component/todo-component.component';
import {TodoServiceService} from "./services/todo-service.service";
import { TodoItemComponent } from './todo-item/todo-item.component';

@NgModule({
  declarations: [
    AppComponent,
    TodoComponentComponent,
    TodoItemComponent
  ],
  imports: [
    BrowserModule, FormsModule, HttpModule
  ],
  providers: [TodoServiceService],
  bootstrap: [AppComponent]
})
export class AppModule { }
