import { Injectable } from '@angular/core';
import {Http, Response} from "@angular/http";

@Injectable()
export class TodoServiceService {

  list = [];

  constructor(private http:Http) {

  }

  saveTodo(description: string){
    this.list.push({completed:false, description: description});
  }

  getTodoList(){    
    return this.list;
  }

  handleError(error:Response){
    console.log(error);
  }
}
