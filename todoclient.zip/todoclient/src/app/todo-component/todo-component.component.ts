import { Component, OnInit } from '@angular/core';
import {TodoServiceService} from "../services/todo-service.service";

@Component({
  selector: 'app-todo-component',
  templateUrl: './todo-component.component.html',
  styleUrls: ['./todo-component.component.css']
})
export class TodoComponentComponent implements OnInit {

  todotext:string;

  todolist: any;

  constructor(private todoSevice: TodoServiceService) { }

  ngOnInit() {
    this.todolist = this.todoSevice.getTodoList();
  }

  get completedList(){
    return this.todolist.filter(function(todo){
      return todo.completed;
    });
  }

  get incompleteList(){
    return this.todolist.filter(function(todo){
      return !todo.completed;
    });
  }

  saveTodo(){
    alert("Save Todo:"+this.todotext);

    this.todoSevice.saveTodo(this.todotext);
    this.todolist = this.todoSevice.getTodoList();
  }

}
